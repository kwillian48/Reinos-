'use strict';
// =====================================================================
//  Reinos de Aço — servidor de um MMORPG 2D original (sem dependências)
//  Requer Node.js 18+.  Rodar:  node server.js   (porta 3000 por padrão)
// =====================================================================
const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const os = require('os');

const PORT = Number(process.env.PORT) || 3000;
const DATA_DIR = path.join(__dirname, 'data');
const DB_FILE = path.join(DATA_DIR, 'players.json');
const PUBLIC = __dirname;

// ---------------------------------------------------------------------
//  Configuração do jogo (mexa à vontade)
// ---------------------------------------------------------------------
const W = 80, H = 60;                 // tamanho do mapa em tiles
const CX = 40, CY = 30;               // centro do mapa (cidade)
const TOWN = { x1: 34, y1: 25, x2: 46, y2: 35 };   // zona segura
const NPC = { x: 42, y: 30 };         // Mercador
const SPAWN = { x: 40, y: 33 };       // ponto de entrada
const VIEW = 22;                      // raio de visão (tiles)
const TICK = 100;                     // ms por tick do servidor
const MOVE_CD = 140;                  // ms mínimos entre passos
const LEASH = 18;                     // distância máx. que o monstro persegue
const POTION_PRICE = 15;
const MAX_LVL = 50;

const CLS = {
  guerreiro:  { name: 'Guerreiro',  e: '🛡️', hp: 120, hpL: 22, atk: 8,  atkL: 2.2, rng: 1, spd: 1000, skill: { name: 'Golpe Poderoso', cd: 5000, mult: 2.6 } },
  arqueiro:   { name: 'Arqueiro',   e: '🏹', hp: 85,  hpL: 14, atk: 9,  atkL: 2.6, rng: 6, spd: 900,  skill: { name: 'Tiro Duplo',     cd: 4000, mult: 1.4 } },
  mago:       { name: 'Mago',       e: '🔮', hp: 70,  hpL: 12, atk: 11, atkL: 3.0, rng: 5, spd: 1100, skill: { name: 'Bola de Fogo',   cd: 6000, mult: 2.0 } },
  curandeiro: { name: 'Curandeiro', e: '✨', hp: 90,  hpL: 16, atk: 6,  atkL: 1.8, rng: 4, spd: 1000, skill: { name: 'Luz Curativa',   cd: 6000, mult: 3.5 } },
};

const MON = {
  slime:     { name: 'Slime',          e: '🟢', lvl: 1,  hp: 30,   atk: [2, 4],   xp: 8,    gold: [1, 3],     move: 900, aggro: 3, rng: 1, cd: 1400, respawn: 15000 },
  lobo:      { name: 'Lobo',           e: '🐺', lvl: 3,  hp: 70,   atk: [5, 9],   xp: 20,   gold: [2, 6],     move: 450, aggro: 6, rng: 1, cd: 1200, respawn: 20000 },
  goblin:    { name: 'Goblin',         e: '👺', lvl: 6,  hp: 130,  atk: [9, 15],  xp: 42,   gold: [4, 10],    move: 600, aggro: 6, rng: 1, cd: 1200, respawn: 25000 },
  orc:       { name: 'Orc',            e: '👹', lvl: 10, hp: 260,  atk: [15, 24], xp: 90,   gold: [8, 18],    move: 700, aggro: 5, rng: 1, cd: 1400, respawn: 30000 },
  esqueleto: { name: 'Esqueleto',      e: '💀', lvl: 15, hp: 420,  atk: [22, 34], xp: 160,  gold: [14, 30],   move: 650, aggro: 7, rng: 1, cd: 1300, respawn: 35000 },
  dragao:    { name: 'Dragão Ancião',  e: '🐉', lvl: 25, hp: 4000, atk: [45, 80], xp: 2500, gold: [200, 400], move: 500, aggro: 9, rng: 2, cd: 1600, respawn: 180000, boss: true },
};

// [tipo, quantidade, distância mínima da cidade, distância máxima]
const SPAWNS = [
  ['slime', 18, 13, 21],
  ['lobo', 16, 18, 27],
  ['goblin', 14, 24, 33],
  ['orc', 12, 30, 39],
  ['esqueleto', 10, 36, 70],
];

const need = l => Math.floor(25 * Math.pow(l, 1.8));
const DIRS = [[0, -1], [1, 0], [0, 1], [-1, 0]];
const SOLID = [0, 1, 1, 0, 0, 0, 1, 1];  // por tipo de tile: 1 árvore, 2 água, 6 casa, 7 fonte

// ---------------------------------------------------------------------
//  Utilidades
// ---------------------------------------------------------------------
const rand = (a, b) => a + Math.random() * (b - a);
const randInt = (a, b) => Math.floor(rand(a, b + 1));
const cheb = (a, b) => Math.max(Math.abs(a.x - b.x), Math.abs(a.y - b.y));
const isTown = (x, y) => x >= TOWN.x1 && x <= TOWN.x2 && y >= TOWN.y1 && y <= TOWN.y2;

// ---------------------------------------------------------------------
//  Geração do mapa (determinística)
// ---------------------------------------------------------------------
function hash2(x, y, s) {
  let h = Math.imul(x, 374761393) ^ Math.imul(y, 668265263) ^ Math.imul(s, 2246822519);
  h = Math.imul(h ^ (h >>> 13), 1274126177);
  h ^= h >>> 16;
  return (h >>> 0) / 4294967296;
}
function vnoise(x, y, s) {
  const x0 = Math.floor(x), y0 = Math.floor(y);
  const fx = x - x0, fy = y - y0;
  const sx = fx * fx * (3 - 2 * fx), sy = fy * fy * (3 - 2 * fy);
  const a = hash2(x0, y0, s), b = hash2(x0 + 1, y0, s), c = hash2(x0, y0 + 1, s), d = hash2(x0 + 1, y0 + 1, s);
  return a + (b - a) * sx + (c - a) * sy + (a - b - c + d) * sx * sy;
}

// tipos: 0 grama, 1 árvore, 2 água, 3 piso da cidade, 4 trilha, 6 casa, 7 fonte
const tiles = new Uint8Array(W * H);
const reach = new Uint8Array(W * H);

function genMap() {
  for (let y = 0; y < H; y++) {
    for (let x = 0; x < W; x++) {
      let v = 0;
      const edge = x < 2 || y < 2 || x >= W - 2 || y >= H - 2;
      const dt = Math.hypot(x - CX, y - CY);
      if (edge) v = 1;
      else if (isTown(x, y)) v = 3;
      else if (dt > 14 && vnoise(x / 8, y / 8, 11) > 0.7) v = 2;
      else if (dt > 13 && ((vnoise(x / 4.5, y / 4.5, 23) > 0.62 && hash2(x, y, 5) < 0.6) || hash2(x, y, 7) < 0.03)) v = 1;
      tiles[y * W + x] = v;
    }
  }
  // trilhas partindo da cidade (atravessam lagos como pontes)
  for (let x = 2; x < W - 2; x++) if (!isTown(x, CY)) tiles[CY * W + x] = 4;
  for (let y = 2; y < H - 2; y++) if (!isTown(CX, y)) tiles[y * W + CX] = 4;
  // casas e fonte
  for (const [hx, hy] of [[35, 26], [37, 26], [43, 26], [45, 26], [35, 34], [45, 34]]) tiles[hy * W + hx] = 6;
  tiles[28 * W + CX] = 7;
  // flood fill: tudo que não é alcançável a pé vira árvore
  const stack = [[SPAWN.x, SPAWN.y]];
  reach[SPAWN.y * W + SPAWN.x] = 1;
  while (stack.length) {
    const [x, y] = stack.pop();
    for (const [dx, dy] of DIRS) {
      const nx = x + dx, ny = y + dy;
      if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
      const i = ny * W + nx;
      if (reach[i] || SOLID[tiles[i]]) continue;
      reach[i] = 1;
      stack.push([nx, ny]);
    }
  }
  for (let i = 0; i < W * H; i++) if (!SOLID[tiles[i]] && !reach[i]) tiles[i] = 1;
}
genMap();

const MAP_ROWS = [];
for (let y = 0; y < H; y++) {
  let s = '';
  for (let x = 0; x < W; x++) s += tiles[y * W + x];
  MAP_ROWS.push(s);
}

const solid = (x, y) => x < 0 || y < 0 || x >= W || y >= H || SOLID[tiles[y * W + x]] === 1;

// ---------------------------------------------------------------------
//  Estado do mundo
// ---------------------------------------------------------------------
const monsters = [];
const monMap = new Map();
const players = new Map();
const conns = new Set();
let monSeq = 0, plSeq = 0;
let evs = [];
const ev = o => evs.push(o);

function addMonster(type, x, y) {
  const d = MON[type];
  const m = {
    id: 'm' + (++monSeq), type, x, y, sx: x, sy: y, hp: d.hp, mhp: d.hp,
    target: null, nextMove: 0, nextAtk: 0, nextRegen: 0, dead: false, respawnAt: 0, dmg: {},
  };
  monsters.push(m);
  monMap.set(m.id, m);
}

function spawnMonsters() {
  const cand = [];
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    if (reach[y * W + x] && !isTown(x, y) && tiles[y * W + x] !== 4) cand.push([x, y, Math.hypot(x - CX, y - CY)]);
  }
  for (const [type, count, dmin, dmax] of SPAWNS) {
    const pool = cand.filter(c => c[2] >= dmin && c[2] < dmax);
    for (let i = 0; i < count && pool.length; i++) {
      const k = randInt(0, pool.length - 1);
      const [x, y] = pool[k];
      pool.splice(k, 1);
      addMonster(type, x, y);
    }
  }
  cand.sort((a, b) => b[2] - a[2]);
  if (cand.length) addMonster('dragao', cand[0][0], cand[0][1]);
}
spawnMonsters();

// ---------------------------------------------------------------------
//  Persistência (arquivo JSON simples)
// ---------------------------------------------------------------------
let db = {};
let dirty = false;
try { db = JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); } catch (e) { db = {}; }

function saveDb() {
  if (!dirty) return;
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    const tmp = DB_FILE + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(db));
    fs.renameSync(tmp, DB_FILE);
    dirty = false;
  } catch (e) { console.error('Erro ao salvar:', e.message); }
}
function syncRec(p) {
  const r = db[p.key];
  if (!r) return;
  r.lvl = p.lvl; r.xp = p.xp; r.gold = p.gold; r.potions = p.potions;
  dirty = true;
}
const hashPw = (pw, salt) => crypto.scryptSync(pw, salt, 32).toString('hex');

// ---------------------------------------------------------------------
//  WebSocket mínimo (RFC 6455) — sem bibliotecas
// ---------------------------------------------------------------------
function frame(op, data) {
  const len = data.length;
  let header;
  if (len < 126) header = Buffer.from([0x80 | op, len]);
  else if (len < 65536) { header = Buffer.alloc(4); header[0] = 0x80 | op; header[1] = 126; header.writeUInt16BE(len, 2); }
  else { header = Buffer.alloc(10); header[0] = 0x80 | op; header[1] = 127; header.writeBigUInt64BE(BigInt(len), 2); }
  return Buffer.concat([header, data]);
}

function send(conn, obj) {
  if (!conn || !conn.alive || conn.socket.destroyed) return;
  if (conn.socket.writableLength > 1e6) return;
  try { conn.socket.write(frame(1, Buffer.from(JSON.stringify(obj)))); } catch (e) { /* ignora */ }
}

function onData(conn, d) {
  conn.buf = Buffer.concat([conn.buf, d]);
  if (conn.buf.length > 1 << 20) { conn.socket.destroy(); return; }
  for (;;) {
    const b = conn.buf;
    if (b.length < 2) return;
    const op = b[0] & 15;
    const masked = !!(b[1] & 128);
    let len = b[1] & 127, off = 2;
    if (len === 126) { if (b.length < 4) return; len = b.readUInt16BE(2); off = 4; }
    else if (len === 127) { if (b.length < 10) return; len = Number(b.readBigUInt64BE(2)); off = 10; }
    if (len > 65536 || !masked) { conn.socket.destroy(); return; }
    if (b.length < off + 4 + len) return;
    const mask = b.subarray(off, off + 4);
    const payload = Buffer.from(b.subarray(off + 4, off + 4 + len));
    for (let i = 0; i < len; i++) payload[i] ^= mask[i & 3];
    conn.buf = b.subarray(off + 4 + len);
    if (op === 8) { try { conn.socket.end(frame(8, Buffer.alloc(0))); } catch (e) { /* ignora */ } return; }
    if (op === 9) { try { conn.socket.write(frame(10, payload)); } catch (e) { /* ignora */ } continue; }
    if (op === 1) handleMsg(conn, payload.toString('utf8'));
  }
}

// ---------------------------------------------------------------------
//  Regras do jogo
// ---------------------------------------------------------------------
function stats(p) {
  const c = CLS[p.cls];
  p.mhp = Math.round(c.hp + c.hpL * (p.lvl - 1));
  p.atk = c.atk + c.atkL * (p.lvl - 1);
  p.def = Math.floor(p.lvl * 1.2);
}

function occupied(x, y, self) {
  if (x === NPC.x && y === NPC.y) return true;
  for (const m of monsters) if (!m.dead && m !== self && m.x === x && m.y === y) return true;
  for (const p of players.values()) if (p !== self && p.x === x && p.y === y) return true;
  return false;
}

function townSpot() {
  for (let i = 0; i < 40; i++) {
    const x = randInt(TOWN.x1, TOWN.x2), y = randInt(TOWN.y1 + 4, TOWN.y2);
    if (!solid(x, y) && !occupied(x, y)) return { x, y };
  }
  return { x: SPAWN.x, y: SPAWN.y };
}

function sys(p, text) { send(p.conn, { t: 'chat', k: 's', m: text }); }
function chatAll(kind, name, text) {
  for (const p of players.values()) send(p.conn, { t: 'chat', k: kind, n: name, m: text });
}

function meOf(p, now) {
  return {
    hp: p.hp, mhp: p.mhp, xp: p.xp, need: need(p.lvl), lvl: p.lvl, gold: p.gold, pot: p.potions,
    tg: p.target, sk: Math.max(0, p.skillAt - now), pc: Math.max(0, p.potAt - now),
    x: p.x, y: p.y, town: isTown(p.x, p.y) ? 1 : 0,
  };
}

function heal(q, amt) {
  const real = Math.min(Math.round(amt), q.mhp - q.hp);
  if (real <= 0) return;
  q.hp += real;
  ev({ k: 'h', x: q.x, y: q.y, v: real });
}

function addXp(p, xp) {
  if (p.lvl >= MAX_LVL) return;
  p.xp += xp;
  let up = false;
  while (p.lvl < MAX_LVL && p.xp >= need(p.lvl)) { p.xp -= need(p.lvl); p.lvl++; up = true; }
  if (up) {
    stats(p);
    p.hp = p.mhp;
    ev({ k: 'lv', x: p.x, y: p.y });
    sys(p, `🎉 Você subiu para o nível ${p.lvl}!`);
  }
  syncRec(p);
}

function killPlayer(p, by) {
  const lost = Math.floor(p.xp * 0.1);
  p.xp -= lost;
  p.hp = p.mhp;
  p.target = null;
  const s = townSpot();
  p.x = s.x; p.y = s.y;
  sys(p, `☠️ ${MON[by.type].name} derrotou você! Perdeu ${lost} XP e voltou à cidade.`);
  syncRec(p);
}

function killMonster(m, killer) {
  const d = MON[m.type];
  m.dead = true; m.hp = 0; m.target = null;
  m.respawnAt = Date.now() + d.respawn;
  const total = Object.values(m.dmg).reduce((a, b) => a + b, 0) || 1;
  let top = null, topD = -1;
  for (const [pid, dm] of Object.entries(m.dmg)) {
    const p = players.get(pid);
    if (!p) continue;
    if (dm > topD) { topD = dm; top = p; }
    const diff = p.lvl - d.lvl;
    const mult = diff > 5 ? Math.max(0.1, 1 - (diff - 5) * 0.15) : 1;
    const xp = Math.max(1, Math.round(d.xp * (dm / total) * mult));
    sys(p, `+${xp} XP (${d.name})`);
    addXp(p, xp);
  }
  if (top) {
    const g = randInt(d.gold[0], d.gold[1]);
    top.gold += g;
    let msg = `+${g} 🪙`;
    const pots = d.boss ? 3 : (Math.random() < 0.1 ? 1 : 0);
    if (pots) { top.potions = Math.min(99, top.potions + pots); msg += ` e +${pots} 🧪`; }
    sys(top, msg);
    syncRec(top);
  }
  m.dmg = {};
  if (d.boss) chatAll('s', null, `⚔️ ${killer.name} e seus aliados derrotaram o ${d.name}!`);
}

function hitMon(p, m, raw, fx) {
  if (m.dead) return;
  const crit = Math.random() < 0.12;
  const dmg = Math.max(1, Math.round(raw * rand(0.9, 1.1) * (crit ? 1.8 : 1)));
  if (fx) ev({ k: 'fx', f: fx, x: p.x, y: p.y, x2: m.x, y2: m.y });
  ev({ k: 'd', x: m.x, y: m.y, v: dmg, to: 'm', c: crit ? 1 : 0 });
  m.hp -= dmg;
  m.dmg[p.id] = (m.dmg[p.id] || 0) + dmg;
  if (!m.target || !players.has(m.target)) m.target = p.id;
  if (m.hp <= 0) killMonster(m, p);
}

const BASIC_FX = { guerreiro: 'slash', arqueiro: 'arrow', mago: 'bolt', curandeiro: 'light' };
function basicAttack(p, m) { hitMon(p, m, p.atk, BASIC_FX[p.cls]); }

function useSkill(p, now) {
  if (now < p.skillAt) return;
  const c = CLS[p.cls], sk = c.skill;
  if (p.cls === 'curandeiro') {
    const amt = 20 + p.atk * sk.mult;
    for (const q of players.values()) if (cheb(p, q) <= 5) heal(q, amt);
    ev({ k: 'fx', f: 'heal', x: p.x, y: p.y, x2: p.x, y2: p.y });
    p.skillAt = now + sk.cd;
    return;
  }
  const m = p.target ? monMap.get(p.target) : null;
  if (!m || m.dead) { sys(p, 'Selecione um alvo primeiro (tecla F).'); return; }
  if (cheb(p, m) > c.rng) { sys(p, 'Alvo fora de alcance.'); return; }
  p.skillAt = now + sk.cd;
  if (p.cls === 'guerreiro') hitMon(p, m, p.atk * sk.mult, 'slash');
  else if (p.cls === 'arqueiro') { hitMon(p, m, p.atk * sk.mult, 'arrow'); hitMon(p, m, p.atk * sk.mult, 'arrow'); }
  else if (p.cls === 'mago') {
    ev({ k: 'fx', f: 'fire', x: p.x, y: p.y, x2: m.x, y2: m.y });
    for (const o of monsters) if (!o.dead && cheb(o, m) <= 1) hitMon(p, o, p.atk * sk.mult, null);
  }
}

function usePotion(p, now) {
  if (p.potions <= 0) { sys(p, 'Você não tem poções. Compre com o Mercador (tecla E).'); return; }
  if (now < p.potAt || p.hp >= p.mhp) return;
  p.potions--;
  p.potAt = now + 2000;
  heal(p, p.mhp * 0.4);
  syncRec(p);
}

function buy(p, n) {
  n = Math.max(1, Math.min(50, n | 0));
  if (cheb(p, NPC) > 3) { sys(p, 'Chegue perto do Mercador 🧙 na cidade.'); return; }
  const cost = n * POTION_PRICE;
  if (p.gold < cost) { sys(p, `Ouro insuficiente: ${n} poção(ões) custam ${cost} 🪙.`); return; }
  if (p.potions + n > 99) { sys(p, 'Você não pode carregar mais de 99 poções.'); return; }
  p.gold -= cost; p.potions += n;
  sys(p, `Comprou ${n} 🧪 por ${cost} 🪙.`);
  syncRec(p);
}

// ----- IA dos monstros -----
function tryMove(m, nx, ny) {
  if (solid(nx, ny) || isTown(nx, ny) || occupied(nx, ny, m)) return false;
  m.x = nx; m.y = ny;
  return true;
}
function stepToward(m, tx, ty) {
  const dx = Math.sign(tx - m.x), dy = Math.sign(ty - m.y);
  const opts = [];
  if (Math.abs(tx - m.x) >= Math.abs(ty - m.y)) { if (dx) opts.push([dx, 0]); if (dy) opts.push([0, dy]); }
  else { if (dy) opts.push([0, dy]); if (dx) opts.push([dx, 0]); }
  if (!dx) opts.push([1, 0], [-1, 0]);
  if (!dy) opts.push([0, 1], [0, -1]);
  for (const [a, b] of opts) if (tryMove(m, m.x + a, m.y + b)) return true;
  return false;
}

function monsterHit(m, p, d, now) {
  const dmg = Math.max(1, randInt(d.atk[0], d.atk[1]) - p.def);
  p.hp -= dmg;
  p.lastHit = now;
  ev({ k: 'fx', f: d.boss ? 'fire' : 'hit', x: m.x, y: m.y, x2: p.x, y2: p.y });
  ev({ k: 'd', x: p.x, y: p.y, v: dmg, to: 'p' });
  if (p.hp <= 0) killPlayer(p, m);
}

function updateMonster(m, now) {
  const d = MON[m.type];
  if (m.dead) {
    if (now >= m.respawnAt) { m.dead = false; m.hp = m.mhp; m.x = m.sx; m.y = m.sy; m.target = null; m.dmg = {}; }
    return;
  }
  const home = { x: m.sx, y: m.sy };
  let tp = m.target ? players.get(m.target) : null;
  if (tp && (tp.hp <= 0 || isTown(tp.x, tp.y) || cheb(tp, home) > LEASH + 6 || cheb(m, home) > LEASH)) { tp = null; m.target = null; }
  if (!tp) {
    let best = null, bd = 1e9;
    for (const p of players.values()) {
      if (p.hp <= 0 || isTown(p.x, p.y)) continue;
      const dd = cheb(m, p);
      if (dd <= d.aggro && dd < bd) { bd = dd; best = p; }
    }
    if (best) { tp = best; m.target = best.id; }
  }
  if (tp) {
    if (cheb(m, tp) <= d.rng) {
      if (now >= m.nextAtk) { m.nextAtk = now + d.cd; monsterHit(m, tp, d, now); }
    } else if (now >= m.nextMove) {
      m.nextMove = now + d.move;
      stepToward(m, tp.x, tp.y);
    }
    return;
  }
  if (now >= m.nextRegen) {
    m.nextRegen = now + 1000;
    if (m.hp < m.mhp) m.hp = Math.min(m.mhp, m.hp + Math.ceil(m.mhp * 0.04));
  }
  if (now >= m.nextMove) {
    m.nextMove = now + d.move * 2;
    if (cheb(m, home) > 3) stepToward(m, home.x, home.y);
    else if (Math.random() < 0.3) { const dir = DIRS[randInt(0, 3)]; tryMove(m, m.x + dir[0], m.y + dir[1]); }
  }
}

function updatePlayer(p, now) {
  if (p.target) {
    const m = monMap.get(p.target);
    const c = CLS[p.cls];
    if (!m || m.dead || cheb(p, m) > VIEW) p.target = null;
    else if (now >= p.nextAtk && cheb(p, m) <= c.rng) { p.nextAtk = now + c.spd; basicAttack(p, m); }
  }
  if (now >= p.nextRegen) {
    p.nextRegen = now + 3000;
    if (p.hp < p.mhp && now - p.lastHit > 4000) {
      const r = isTown(p.x, p.y) ? 0.1 : 0.02;
      p.hp = Math.min(p.mhp, p.hp + Math.ceil(p.mhp * r));
    }
  }
}

// ----- mensagens do cliente -----
function fail(conn, msg) { send(conn, { t: 'err', m: msg }); }

function doJoin(conn, m) {
  if (conn.player) return;
  const name = String(m.name || '').trim();
  const pass = String(m.pass || '');
  if (!/^[A-Za-zÀ-ÿ0-9_]{3,14}$/.test(name)) return fail(conn, 'Nome inválido: use de 3 a 14 letras, números ou _.');
  if (pass.length < 3 || pass.length > 64) return fail(conn, 'A senha precisa ter de 3 a 64 caracteres.');
  const key = name.toLowerCase();
  for (const p of players.values()) if (p.key === key) return fail(conn, 'Esse personagem já está online.');
  let rec = db[key];
  if (rec) {
    let ok = false;
    try { ok = crypto.timingSafeEqual(Buffer.from(hashPw(pass, rec.salt), 'hex'), Buffer.from(rec.hash, 'hex')); } catch (e) { ok = false; }
    if (!ok) return fail(conn, 'Senha incorreta para esse personagem.');
  } else {
    if (!CLS[m.cls]) return fail(conn, 'Escolha uma classe.');
    const salt = crypto.randomBytes(16).toString('hex');
    rec = { name, cls: m.cls, lvl: 1, xp: 0, gold: 20, potions: 3, salt, hash: hashPw(pass, salt), created: Date.now() };
    db[key] = rec;
    dirty = true;
  }
  const s = townSpot();
  const p = {
    id: 'p' + (++plSeq), key, name: rec.name, cls: rec.cls, lvl: rec.lvl, xp: rec.xp, gold: rec.gold, potions: rec.potions,
    x: s.x, y: s.y, target: null, conn, nextAtk: 0, skillAt: 0, potAt: 0, lastMove: 0, lastHit: 0, lastSay: 0, nextRegen: 0,
  };
  stats(p);
  p.hp = p.mhp;
  conn.player = p;
  players.set(p.id, p);
  const mon = {};
  for (const [k, v] of Object.entries(MON)) mon[k] = { name: v.name, e: v.e, lvl: v.lvl, boss: !!v.boss };
  const cls = {};
  for (const [k, v] of Object.entries(CLS)) cls[k] = { name: v.name, e: v.e, rng: v.rng, skill: { name: v.skill.name, cd: v.skill.cd } };
  send(conn, {
    t: 'init', id: p.id, name: p.name, cls: p.cls, w: W, h: H, rows: MAP_ROWS, npc: NPC, town: TOWN,
    mon, classes: cls, price: POTION_PRICE, me: meOf(p, Date.now()),
  });
  sys(p, `Bem-vindo, ${p.name}! Digite /ajuda para ver os comandos.`);
  chatAll('s', null, `${p.name} entrou no reino.`);
  console.log(`+ ${p.name} (${p.cls}) entrou — ${players.size} online`);
}

function doSay(p, text) {
  text = String(text || '').replace(/[\u0000-\u001f]/g, '').trim().slice(0, 120);
  if (!text) return;
  const now = Date.now();
  if (now - p.lastSay < 700) return;
  p.lastSay = now;
  if (text[0] === '/') {
    const [cmd, ...a] = text.slice(1).split(/\s+/);
    switch (cmd.toLowerCase()) {
      case 'ajuda': sys(p, 'Comandos: /online, /comprar N, /ajuda. Teclas: WASD mover, F alvo, 1 habilidade, Q poção, E comprar, Enter chat.'); break;
      case 'online': sys(p, `Online (${players.size}): ` + [...players.values()].map(q => `${q.name} (Nv ${q.lvl})`).join(', ')); break;
      case 'comprar': buy(p, parseInt(a[0], 10) || 1); break;
      default: sys(p, 'Comando desconhecido. Use /ajuda.');
    }
    return;
  }
  chatAll('g', p.name, text);
}

function handleMsg(conn, raw) {
  const now = Date.now();
  if (now - conn.win > 1000) { conn.win = now; conn.count = 0; }
  if (++conn.count > 60) { conn.socket.destroy(); return; }
  let m;
  try { m = JSON.parse(raw); } catch (e) { return; }
  if (!m || typeof m !== 'object') return;
  if (m.t === 'join') return doJoin(conn, m);
  const p = conn.player;
  if (!p) return;
  switch (m.t) {
    case 'mv': {
      const d = m.d | 0;
      if (d < 0 || d > 3 || now - p.lastMove < MOVE_CD) break;
      const nx = p.x + DIRS[d][0], ny = p.y + DIRS[d][1];
      if (!solid(nx, ny) && !occupied(nx, ny, p)) { p.x = nx; p.y = ny; p.lastMove = now; }
      break;
    }
    case 'tg': {
      if (m.id === 'near') {
        let best = null, bd = 1e9;
        for (const o of monsters) { if (o.dead) continue; const dd = cheb(p, o); if (dd < bd && dd <= 14) { bd = dd; best = o; } }
        p.target = best ? best.id : null;
      } else if (typeof m.id === 'string') {
        const o = monMap.get(m.id);
        p.target = o && !o.dead && cheb(p, o) <= VIEW ? o.id : null;
      } else p.target = null;
      break;
    }
    case 'sk': useSkill(p, now); break;
    case 'pot': usePotion(p, now); break;
    case 'buy': buy(p, m.n); break;
    case 'say': doSay(p, m.m); break;
  }
}

function onClose(conn) {
  conn.alive = false;
  conns.delete(conn);
  const p = conn.player;
  if (!p) return;
  players.delete(p.id);
  for (const o of monsters) if (o.target === p.id) o.target = null;
  syncRec(p);
  saveDb();
  chatAll('s', null, `${p.name} saiu do reino.`);
  console.log(`- ${p.name} saiu — ${players.size} online`);
}

// ---------------------------------------------------------------------
//  Loop principal
// ---------------------------------------------------------------------
function broadcast(now) {
  for (const p of players.values()) {
    const ps = [], ms = [];
    for (const q of players.values()) if (cheb(p, q) <= VIEW) ps.push([q.id, q.name, q.cls, q.lvl, q.x, q.y, q.hp, q.mhp]);
    for (const m of monsters) if (!m.dead && cheb(p, m) <= VIEW) ms.push([m.id, m.type, m.x, m.y, m.hp, m.mhp]);
    const e = evs.filter(o => Math.abs(o.x - p.x) <= VIEW && Math.abs(o.y - p.y) <= VIEW);
    send(p.conn, { t: 's', me: meOf(p, now), p: ps, m: ms, ev: e });
  }
}

function tick() {
  const now = Date.now();
  for (const m of monsters) updateMonster(m, now);
  for (const p of players.values()) updatePlayer(p, now);
  broadcast(now);
  evs = [];
}
setInterval(tick, TICK);
setInterval(() => { for (const p of players.values()) syncRec(p); saveDb(); }, 30000);
setInterval(() => { for (const c of conns) { try { c.socket.write(frame(9, Buffer.alloc(0))); } catch (e) { /* ignora */ } } }, 25000);

// ---------------------------------------------------------------------
//  Servidor HTTP (arquivos estáticos) + upgrade para WebSocket
// ---------------------------------------------------------------------
const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.png': 'image/png', '.ico': 'image/x-icon', '.svg': 'image/svg+xml', '.json': 'application/json',
};

const server = http.createServer((req, res) => {
  let p;
  try { p = decodeURIComponent((req.url || '/').split('?')[0]); } catch (e) { res.writeHead(400); return res.end('400'); }
  if (p === '/') p = '/index.html';
  // Versão com arquivos soltos: só estes 3 são públicos (server.js e data/ nunca são servidos).
  if (p !== '/index.html' && p !== '/style.css' && p !== '/game.js') { res.writeHead(404); return res.end('404'); }
  const f = path.join(PUBLIC, p);
  fs.readFile(f, (err, data) => {
    if (err) { res.writeHead(404); return res.end('404'); }
    res.writeHead(200, { 'Content-Type': MIME[path.extname(f)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
    res.end(data);
  });
});

server.on('upgrade', (req, socket) => {
  const key = req.headers['sec-websocket-key'];
  if (!key || String(req.headers.upgrade).toLowerCase() !== 'websocket') { socket.destroy(); return; }
  const accept = crypto.createHash('sha1').update(key + '258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
  socket.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: ' + accept + '\r\n\r\n');
  socket.setNoDelay(true);
  const conn = { socket, player: null, buf: Buffer.alloc(0), alive: true, win: Date.now(), count: 0 };
  conns.add(conn);
  socket.on('data', d => onData(conn, d));
  socket.on('close', () => onClose(conn));
  socket.on('error', () => socket.destroy());
});

server.on('error', e => { console.error('Erro no servidor:', e.message); process.exit(1); });

server.listen(PORT, '0.0.0.0', () => {
  console.log('⚔️  Reinos de Aço no ar!');
  console.log(`   Neste computador:  http://localhost:${PORT}`);
  for (const list of Object.values(os.networkInterfaces())) {
    for (const i of list || []) if (i.family === 'IPv4' && !i.internal) console.log(`   Na sua rede local: http://${i.address}:${PORT}`);
  }
  console.log(`   Monstros: ${monsters.length} | Personagens salvos: ${Object.keys(db).length}`);
});

function shutdown() { saveDb(); process.exit(0); }
process.on('SIGINT', shutdown);
process.on('SIGTERM', shutdown);
