'use strict';
// Reinos de Aço — cliente (canvas 2D). Gráficos feitos com emojis: nenhum arquivo de imagem.
(() => {
  const $ = id => document.getElementById(id);
  const cv = $('c'), ctx = cv.getContext('2d');
  const touch = (window.matchMedia && matchMedia('(pointer: coarse)').matches) || 'ontouchstart' in window;
  document.body.classList.toggle('touch', !!touch);

  // ------------------------------------------------------------ estado
  let DPR = 1, VW = 0, VH = 0, TS = 32;
  let ws = null, joined = false, typing = false;
  let myId = null, myName = '', myCls = 'guerreiro';
  let map = null, MW = 0, MH = 0, npc = null, MONI = {}, CLSI = {};
  let me = null;
  let cdSkEnd = 0, cdPotEnd = 0;
  const ents = new Map();
  const floaters = [];
  const fxs = [];
  const held = [];
  let lastMv = 0;
  let chosen = 'guerreiro';

  // ------------------------------------------------------------ canvas / sprites
  const sprites = new Map();
  function resize() {
    DPR = Math.min(2, window.devicePixelRatio || 1);
    VW = window.innerWidth; VH = window.innerHeight;
    cv.width = Math.floor(VW * DPR); cv.height = Math.floor(VH * DPR);
    cv.style.width = VW + 'px'; cv.style.height = VH + 'px';
    TS = Math.max(28, Math.min(48, Math.floor(Math.min(VW, VH) / 12)));
    sprites.clear();
  }
  window.addEventListener('resize', resize);
  resize();

  function spr(e, size) {
    const k = e + '|' + size;
    let c = sprites.get(k);
    if (c) return c;
    const s = Math.ceil(size * 1.5);
    c = document.createElement('canvas');
    c.width = c.height = Math.ceil(s * DPR);
    const g = c.getContext('2d');
    g.scale(DPR, DPR);
    g.font = size + 'px "Apple Color Emoji","Segoe UI Emoji","Noto Color Emoji",sans-serif';
    g.textAlign = 'center';
    g.textBaseline = 'middle';
    g.fillText(e, s / 2, s / 2 + size * 0.05);
    c.logical = s;
    sprites.set(k, c);
    return c;
  }
  function drawSpr(e, cx, cy, size) {
    const c = spr(e, Math.round(size));
    ctx.drawImage(c, cx - c.logical / 2, cy - c.logical / 2, c.logical, c.logical);
  }

  // ------------------------------------------------------------ rede
  function send(o) { if (ws && ws.readyState === 1) ws.send(JSON.stringify(o)); }

  function connect(name, pass, cls) {
    $('err').textContent = '';
    if (ws && ws.readyState === 1) { ws.send(JSON.stringify({ t: 'join', name, pass, cls })); return; }
    const proto = location.protocol === 'https:' ? 'wss' : 'ws';
    ws = new WebSocket(proto + '://' + location.host);
    ws.onopen = () => ws.send(JSON.stringify({ t: 'join', name, pass, cls }));
    ws.onmessage = e => { let m; try { m = JSON.parse(e.data); } catch (x) { return; } onMsg(m); };
    ws.onclose = () => {
      if (joined) $('lost').classList.remove('hidden');
      else $('err').textContent = 'Não foi possível conectar ao servidor.';
    };
  }

  function onMsg(m) {
    switch (m.t) {
      case 'err': $('err').textContent = m.m; break;
      case 'init': {
        joined = true; myId = m.id; myName = m.name; myCls = m.cls;
        MW = m.w; MH = m.h; npc = m.npc; MONI = m.mon; CLSI = m.classes;
        map = new Uint8Array(MW * MH);
        for (let y = 0; y < MH; y++) for (let x = 0; x < MW; x++) map[y * MW + x] = m.rows[y].charCodeAt(x) - 48;
        me = m.me;
        $('login').classList.add('hidden');
        for (const id of ['hud', 'chat', 'acts', 'help']) $(id).classList.remove('hidden');
        if (touch) $('dpad').classList.remove('hidden');
        $('skE').textContent = CLSI[myCls].e;
        $('skN').textContent = CLSI[myCls].skill.name;
        try { localStorage.setItem('nick', myName); } catch (x) { /* ignora */ }
        break;
      }
      case 's': {
        me = m.me;
        const now = performance.now();
        cdSkEnd = now + me.sk; cdPotEnd = now + me.pc;
        const seen = new Set();
        for (const a of m.p) {
          const e = upsert(a[0], 'p', a[4], a[5], a[6], a[7]);
          e.name = a[1]; e.cls = a[2]; e.lvl = a[3]; e.e = CLSI[a[2]] ? CLSI[a[2]].e : '🙂';
          seen.add(a[0]);
        }
        for (const a of m.m) {
          const info = MONI[a[1]] || { name: '?', e: '❓', lvl: 1 };
          const e = upsert(a[0], 'm', a[2], a[3], a[4], a[5]);
          e.name = info.name; e.lvl = info.lvl; e.e = info.e; e.boss = !!info.boss;
          seen.add(a[0]);
        }
        for (const id of [...ents.keys()]) if (!seen.has(id)) ents.delete(id);
        for (const o of m.ev) handleEv(o, now);
        updateHud();
        break;
      }
      case 'chat': addChat(m.k, m.n, m.m); break;
    }
  }

  function upsert(id, kind, x, y, hp, mhp) {
    let e = ents.get(id);
    if (!e) { e = { id, kind, x, y, rx: x, ry: y }; ents.set(id, e); }
    e.x = x; e.y = y; e.hp = hp; e.mhp = mhp;
    return e;
  }

  function handleEv(o, now) {
    if (o.k === 'd') {
      floaters.push({ x: o.x, y: o.y, txt: String(o.v), col: o.to === 'p' ? '#ff6b6b' : (o.c ? '#ffd43b' : '#ffffff'), big: !!o.c, t0: now });
    } else if (o.k === 'h') {
      floaters.push({ x: o.x, y: o.y, txt: '+' + o.v, col: '#69db7c', big: false, t0: now });
    } else if (o.k === 'lv') {
      floaters.push({ x: o.x, y: o.y - 0.6, txt: 'NÍVEL ACIMA!', col: '#ffe066', big: true, t0: now });
    } else if (o.k === 'fx') {
      const dur = { arrow: 220, bolt: 240, light: 240, slash: 220, fire: 450, heal: 600, hit: 220 }[o.f] || 250;
      fxs.push({ f: o.f, x: o.x, y: o.y, x2: o.x2, y2: o.y2, t0: now, dur });
    }
    if (floaters.length > 80) floaters.splice(0, floaters.length - 80);
    if (fxs.length > 80) fxs.splice(0, fxs.length - 80);
  }

  // ------------------------------------------------------------ HUD
  const pct = (a, b) => Math.max(0, Math.min(100, b ? (a / b) * 100 : 0));
  function nearNpc() { return me && npc && Math.max(Math.abs(me.x - npc.x), Math.abs(me.y - npc.y)) <= 3; }

  function updateHud() {
    if (!me) return;
    $('who').textContent = CLSI[myCls].e + ' ' + myName + ' · Nv ' + me.lvl;
    $('hpf').style.width = pct(me.hp, me.mhp) + '%';
    $('hpt').textContent = me.hp + ' / ' + me.mhp;
    $('xpf').style.width = pct(me.xp, me.need) + '%';
    $('xpt').textContent = 'XP ' + me.xp + ' / ' + me.need;
    $('inv').textContent = '🪙 ' + me.gold + '   🧪 ' + me.pot + (me.town ? '   🏰 Zona segura' : '');
    $('potn').textContent = String(me.pot);
    const t = me.tg ? ents.get(me.tg) : null;
    if (t) {
      $('tgt').classList.remove('hidden');
      $('tgn').textContent = t.name + ' · Nv ' + t.lvl;
      $('tgf').style.width = pct(t.hp, t.mhp) + '%';
      $('tgh').textContent = t.hp + ' / ' + t.mhp;
    } else $('tgt').classList.add('hidden');
    $('bBuy').classList.toggle('hidden', !nearNpc());
  }

  function updateCooldowns(now) {
    if (!joined) return;
    const cd = CLSI[myCls].skill.cd;
    const rem = Math.max(0, cdSkEnd - now);
    $('skCd').style.height = pct(rem, cd) + '%';
  }

  function addChat(kind, name, text) {
    const log = $('log');
    const d = document.createElement('div');
    d.className = 'l ' + kind;
    if (name) { const b = document.createElement('b'); b.textContent = name + ': '; d.appendChild(b); }
    d.appendChild(document.createTextNode(text));
    log.appendChild(d);
    while (log.children.length > 60) log.removeChild(log.firstChild);
    log.scrollTop = log.scrollHeight;
  }

  // ------------------------------------------------------------ entrada
  const KEYDIR = { w: 0, arrowup: 0, d: 1, arrowright: 1, s: 2, arrowdown: 2, a: 3, arrowleft: 3 };
  function press(d) { const i = held.indexOf(d); if (i >= 0) held.splice(i, 1); held.push(d); }
  function release(d) { const i = held.indexOf(d); if (i >= 0) held.splice(i, 1); }

  function act(a) {
    if (!joined) return;
    if (a === 'sk') send({ t: 'sk' });
    else if (a === 'pot') send({ t: 'pot' });
    else if (a === 'tg') send({ t: 'tg', id: 'near' });
    else if (a === 'buy') send({ t: 'buy', n: 1 });
  }

  function openChat() { $('cf').classList.add('on'); typing = true; held.length = 0; $('ci').focus(); }
  function closeChat() { $('cf').classList.remove('on'); typing = false; $('ci').blur(); }

  window.addEventListener('keydown', e => {
    if (!joined) return;
    if (typing) { if (e.key === 'Escape') closeChat(); return; }
    const k = e.key.toLowerCase();
    if (k in KEYDIR) { press(KEYDIR[k]); e.preventDefault(); }
    else if (k === 'enter') { openChat(); e.preventDefault(); }
    else if (k === ' ' || k === '1') { act('sk'); e.preventDefault(); }
    else if (k === 'q') act('pot');
    else if (k === 'e') act('buy');
    else if (k === 'f' || k === 'tab') { act('tg'); e.preventDefault(); }
    else if (k === 'escape') send({ t: 'tg', id: null });
  });
  window.addEventListener('keyup', e => { const k = e.key.toLowerCase(); if (k in KEYDIR) release(KEYDIR[k]); });
  window.addEventListener('blur', () => { held.length = 0; });

  document.querySelectorAll('#dpad button').forEach(b => {
    const d = Number(b.dataset.d);
    const on = e => { e.preventDefault(); press(d); };
    const off = e => { e.preventDefault(); release(d); };
    b.addEventListener('pointerdown', on);
    b.addEventListener('pointerup', off);
    b.addEventListener('pointercancel', off);
    b.addEventListener('pointerleave', off);
  });
  const tap = (id, fn) => $(id).addEventListener('pointerdown', e => { e.preventDefault(); fn(); });
  tap('bSk', () => act('sk'));
  tap('bPot', () => act('pot'));
  tap('bTg', () => act('tg'));
  tap('bBuy', () => act('buy'));
  tap('bChat', () => (typing ? closeChat() : openChat()));

  $('cf').addEventListener('submit', e => {
    e.preventDefault();
    const v = $('ci').value.trim();
    if (v) send({ t: 'say', m: v });
    $('ci').value = '';
    closeChat();
  });

  cv.addEventListener('pointerdown', e => {
    if (!joined || !me) return;
    const cam = camera();
    const wx = (e.clientX - cam.ox) / TS - 0.5, wy = (e.clientY - cam.oy) / TS - 0.5;
    let best = null, bd = 0.9;
    for (const t of ents.values()) {
      if (t.kind !== 'm') continue;
      const d = Math.hypot(t.rx - wx, t.ry - wy);
      if (d < bd) { bd = d; best = t; }
    }
    send({ t: 'tg', id: best ? best.id : null });
  });

  // login
  document.querySelectorAll('.cls').forEach(b => b.addEventListener('click', () => {
    chosen = b.dataset.c;
    document.querySelectorAll('.cls').forEach(x => x.classList.toggle('sel', x === b));
  }));
  try { const n = localStorage.getItem('nick'); if (n) $('nick').value = n; } catch (x) { /* ignora */ }
  $('lf').addEventListener('submit', e => {
    e.preventDefault();
    connect($('nick').value.trim(), $('pass').value, chosen);
  });

  // ------------------------------------------------------------ desenho
  const GRASS = ['#3f7a35', '#44813a', '#3b7231', '#488640'];
  function camera() {
    const self = ents.get(myId);
    let cx = self ? self.rx : (me ? me.x : 0), cy = self ? self.ry : (me ? me.y : 0);
    const hw = VW / 2 / TS, hh = VH / 2 / TS;
    if (MW > hw * 2) cx = Math.max(hw - 0.5, Math.min(MW - hw - 0.5, cx));
    if (MH > hh * 2) cy = Math.max(hh - 0.5, Math.min(MH - hh - 0.5, cy));
    return { cx, cy, hw, hh, ox: VW / 2 - (cx + 0.5) * TS, oy: VH / 2 - (cy + 0.5) * TS };
  }

  function drawTile(t, x, y, px, py, now) {
    const s = TS + 1;
    switch (t) {
      case 2:
        ctx.fillStyle = 'hsl(207,55%,' + (38 + Math.sin(now / 700 + x * 0.9 + y * 1.3) * 3).toFixed(1) + '%)';
        ctx.fillRect(px, py, s, s);
        break;
      case 3:
        ctx.fillStyle = (x + y) % 2 ? '#8f8c80' : '#9a978a';
        ctx.fillRect(px, py, s, s);
        ctx.strokeStyle = 'rgba(0,0,0,.14)';
        ctx.strokeRect(px + 0.5, py + 0.5, TS, TS);
        break;
      case 4:
        ctx.fillStyle = (x * 3 + y) % 3 ? '#a98d5b' : '#b09462';
        ctx.fillRect(px, py, s, s);
        break;
      case 6:
      case 7:
        ctx.fillStyle = '#8f8c80';
        ctx.fillRect(px, py, s, s);
        break;
      default:
        ctx.fillStyle = GRASS[(x * 7 + y * 13) & 3];
        ctx.fillRect(px, py, s, s);
        if (((x * 31 + y * 17) % 5) === 0) {
          ctx.fillStyle = 'rgba(0,0,0,.10)';
          ctx.fillRect(px + TS * 0.3, py + TS * 0.55, 2, TS * 0.18);
          ctx.fillRect(px + TS * 0.55, py + TS * 0.62, 2, TS * 0.14);
        }
    }
  }

  function label(text, x, y, color) {
    ctx.font = 'bold ' + Math.max(10, Math.round(TS * 0.3)) + 'px system-ui,sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'alphabetic';
    ctx.lineWidth = 3;
    ctx.strokeStyle = 'rgba(0,0,0,.75)';
    ctx.strokeText(text, x, y);
    ctx.fillStyle = color;
    ctx.fillText(text, x, y);
  }

  function drawEnt(e, ox, oy, now) {
    const sx = ox + (e.rx + 0.5) * TS, sy = oy + (e.ry + 0.5) * TS;
    const size = TS * (e.boss ? 1.9 : 0.95);
    const bob = Math.sin(now / 300 + e.rx * 1.7 + e.ry) * 1.2;
    ctx.fillStyle = 'rgba(0,0,0,.28)';
    ctx.beginPath();
    ctx.ellipse(sx, sy + size * 0.32, size * 0.32, size * 0.12, 0, 0, Math.PI * 2);
    ctx.fill();
    if (e.id === myId) {
      ctx.strokeStyle = 'rgba(255,214,10,.9)'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.ellipse(sx, sy + size * 0.32, size * 0.4, size * 0.16, 0, 0, Math.PI * 2); ctx.stroke();
    }
    if (me && me.tg === e.id) {
      ctx.strokeStyle = 'rgba(255,70,70,' + (0.65 + Math.sin(now / 150) * 0.3).toFixed(2) + ')'; ctx.lineWidth = 3;
      ctx.beginPath(); ctx.ellipse(sx, sy + size * 0.32, size * 0.48, size * 0.2, 0, 0, Math.PI * 2); ctx.stroke();
    }
    drawSpr(e.e, sx, sy - 2 + bob, size);
    const top = sy - size * 0.55;
    if (e.kind === 'p' || e.kind === 'm') {
      if (e.kind === 'p' || e.hp < e.mhp || (me && me.tg === e.id)) {
        const bw = Math.round(TS * (e.boss ? 1.6 : 0.9)), bh = Math.max(4, Math.round(TS * 0.12));
        ctx.fillStyle = 'rgba(0,0,0,.7)';
        ctx.fillRect(sx - bw / 2 - 1, top - bh - 1, bw + 2, bh + 2);
        ctx.fillStyle = e.kind === 'p' ? '#51cf66' : '#e5484d';
        ctx.fillRect(sx - bw / 2, top - bh, bw * pct(e.hp, e.mhp) / 100, bh);
      }
      const col = e.id === myId ? '#ffe066' : (e.kind === 'p' ? '#ffffff' : (e.boss ? '#ff8787' : '#ffd8a8'));
      label(e.name + ' [' + e.lvl + ']', sx, top - Math.max(4, Math.round(TS * 0.12)) - 4, col);
    } else if (e.kind === 'n') {
      label(e.name, sx, top - 2, '#74c0fc');
    }
  }

  function drawFx(f, p, ox, oy) {
    const X = v => ox + (v + 0.5) * TS, Y = v => oy + (v + 0.5) * TS;
    const x1 = X(f.x), y1 = Y(f.y), x2 = X(f.x2), y2 = Y(f.y2);
    ctx.save();
    switch (f.f) {
      case 'arrow': {
        const px = x1 + (x2 - x1) * p, py = y1 + (y2 - y1) * p;
        const a = Math.atan2(y2 - y1, x2 - x1);
        ctx.strokeStyle = '#f1e3b5'; ctx.lineWidth = 3;
        ctx.beginPath(); ctx.moveTo(px - Math.cos(a) * TS * 0.5, py - Math.sin(a) * TS * 0.5); ctx.lineTo(px, py); ctx.stroke();
        break;
      }
      case 'bolt':
      case 'light': {
        const px = x1 + (x2 - x1) * p, py = y1 + (y2 - y1) * p;
        const col = f.f === 'bolt' ? '116,192,252' : '255,224,102';
        const g = ctx.createRadialGradient(px, py, 1, px, py, TS * 0.45);
        g.addColorStop(0, 'rgba(255,255,255,.95)');
        g.addColorStop(0.4, 'rgba(' + col + ',.8)');
        g.addColorStop(1, 'rgba(' + col + ',0)');
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.arc(px, py, TS * 0.45, 0, Math.PI * 2); ctx.fill();
        break;
      }
      case 'slash':
        ctx.globalAlpha = 1 - p; ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 4; ctx.lineCap = 'round';
        ctx.beginPath(); ctx.arc(x2, y2, TS * 0.45, -1.2 + p * 2.2, 0.2 + p * 2.2); ctx.stroke();
        break;
      case 'fire':
        ctx.globalAlpha = 1;
        ctx.fillStyle = 'rgba(255,' + Math.round(150 - p * 90) + ',30,' + (0.75 * (1 - p)).toFixed(2) + ')';
        ctx.beginPath(); ctx.arc(x2, y2, TS * (0.3 + 1.4 * p), 0, Math.PI * 2); ctx.fill();
        break;
      case 'heal':
        ctx.globalAlpha = 1 - p; ctx.strokeStyle = '#69db7c'; ctx.lineWidth = 4;
        ctx.beginPath(); ctx.arc(x1, y1, TS * (0.3 + 2.6 * p), 0, Math.PI * 2); ctx.stroke();
        break;
      case 'hit':
        ctx.globalAlpha = 1 - p; ctx.fillStyle = '#ff6b6b';
        ctx.beginPath(); ctx.arc(x2, y2, TS * (0.15 + 0.35 * p), 0, Math.PI * 2); ctx.fill();
        break;
    }
    ctx.restore();
  }

  function render(now) {
    ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
    ctx.fillStyle = '#08130b';
    ctx.fillRect(0, 0, VW, VH);
    if (!joined || !map || !me) return;
    const { cx, cy, hw, hh, ox, oy } = camera();
    const x0 = Math.max(0, Math.floor(cx - hw) - 1), x1 = Math.min(MW - 1, Math.ceil(cx + hw) + 1);
    const y0 = Math.max(0, Math.floor(cy - hh) - 1), y1 = Math.min(MH - 1, Math.ceil(cy + hh) + 1);

    for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) {
      drawTile(map[y * MW + x], x, y, Math.floor(ox + x * TS), Math.floor(oy + y * TS), now);
    }
    for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) {
      const t = map[y * MW + x];
      if (t === 1) drawSpr('🌲', ox + (x + 0.5) * TS, oy + (y + 0.45) * TS, TS * 1.1);
      else if (t === 6) drawSpr('🏠', ox + (x + 0.5) * TS, oy + (y + 0.45) * TS, TS * 1.15);
      else if (t === 7) drawSpr('⛲', ox + (x + 0.5) * TS, oy + (y + 0.45) * TS, TS * 1.1);
    }

    const list = [...ents.values()];
    if (npc) list.push({ id: 'npc', kind: 'n', name: 'Mercador', e: '🧙', rx: npc.x, ry: npc.y });
    list.sort((a, b) => a.ry - b.ry);
    for (const e of list) {
      if (e.rx < cx - hw - 2 || e.rx > cx + hw + 2 || e.ry < cy - hh - 2 || e.ry > cy + hh + 2) continue;
      drawEnt(e, ox, oy, now);
    }

    for (let i = fxs.length - 1; i >= 0; i--) {
      const f = fxs[i], p = (now - f.t0) / f.dur;
      if (p >= 1) { fxs.splice(i, 1); continue; }
      if (p >= 0) drawFx(f, p, ox, oy);
    }

    for (let i = floaters.length - 1; i >= 0; i--) {
      const f = floaters[i], age = now - f.t0;
      if (age > 1100) { floaters.splice(i, 1); continue; }
      const px = ox + (f.x + 0.5) * TS, py = oy + f.y * TS - (age / 1100) * TS * 1.2;
      ctx.globalAlpha = age < 700 ? 1 : 1 - (age - 700) / 400;
      ctx.font = 'bold ' + Math.round(TS * (f.big ? 0.62 : 0.46)) + 'px system-ui,sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'alphabetic';
      ctx.lineWidth = 3;
      ctx.strokeStyle = 'rgba(0,0,0,.8)';
      ctx.strokeText(f.txt, px, py);
      ctx.fillStyle = f.col;
      ctx.fillText(f.txt, px, py);
      ctx.globalAlpha = 1;
    }
  }

  // ------------------------------------------------------------ loop
  let last = performance.now();
  function frame(now) {
    const dt = Math.min(0.1, (now - last) / 1000);
    last = now;
    if (joined && held.length && !typing && now - lastMv >= 150) {
      lastMv = now;
      send({ t: 'mv', d: held[held.length - 1] });
    }
    const k = Math.min(1, dt * 14);
    for (const e of ents.values()) {
      e.rx += (e.x - e.rx) * k;
      e.ry += (e.y - e.ry) * k;
      if (Math.abs(e.x - e.rx) > 5 || Math.abs(e.y - e.ry) > 5) { e.rx = e.x; e.ry = e.y; }
    }
    updateCooldowns(now);
    render(now);
    requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
})();
