# ⚔️ Reinos de Aço

MMORPG 2D multiplayer **original**, inspirado no estilo dos MMOs de fantasia clássicos. Roda no navegador (PC ou celular) e o servidor é um único arquivo Node.js **sem dependências**.

## Como rodar

Requisito: [Node.js](https://nodejs.org) 18 ou mais novo.

```bash
cd reinos-de-aco
node server.js
```

Abra `http://localhost:3000`. O terminal também mostra o endereço da sua rede local (ex.: `http://192.168.0.10:3000`): amigos e celulares no mesmo Wi-Fi entram por ele.

Para mudar a porta: `PORT=8080 node server.js`.

## Colocar online (para jogar com amigos de fora)

- **VPS / Raspberry Pi:** rode `node server.js` (use `pm2` ou `systemd` para manter ligado) e libere a porta no firewall.
- **Render, Railway, Fly.io etc.:** crie um serviço Node com comando de início `node server.js`. Eles definem `PORT` sozinhos e fornecem HTTPS; o cliente usa `wss://` automaticamente.
- **Túnel rápido:** `ngrok http 3000` ou `cloudflared tunnel --url http://localhost:3000`.

Os personagens ficam em `data/players.json` (faça backup desse arquivo). Em hospedagens com disco temporário, use um volume persistente, senão o progresso se perde ao reiniciar.

## Como jogar

| Ação | PC | Celular |
|---|---|---|
| Mover | WASD / setas | direcional na tela |
| Mirar no monstro mais próximo | F ou Tab | botão 🎯 |
| Mirar clicando | clique no monstro | toque no monstro |
| Habilidade da classe | 1 ou Espaço | botão grande |
| Beber poção | Q | 🧪 |
| Comprar poção (perto do Mercador 🧙) | E | 🛒 |
| Chat | Enter | botão 💬 |

O ataque básico é automático quando o alvo está ao alcance. Comandos de chat: `/ajuda`, `/online`, `/comprar N`.

**Classes:** 🛡️ Guerreiro (Golpe Poderoso) · 🏹 Arqueiro (Tiro Duplo) · 🔮 Mago (Bola de Fogo em área) · ✨ Curandeiro (Luz Curativa em você e aliados próximos).

**Mundo:** cidade central (zona segura, sem monstros) cercada por regiões cada vez mais perigosas: Slimes → Lobos → Goblins → Orcs → Esqueletos, e o chefe 🐉 Dragão Ancião no ponto mais distante do mapa. Ao morrer você volta à cidade e perde 10% do XP do nível atual. O XP é dividido entre quem causou dano ao monstro.

## Personalizar

Tudo fica no começo de `server.js`:

- `CLS`: classes (vida, ataque, alcance, habilidade).
- `MON` e `SPAWNS`: monstros, atributos, recompensas e quantidade por região.
- `W`, `H`, `TOWN`: tamanho do mapa e da cidade (o mapa é gerado automaticamente, sempre igual).

Os gráficos são emojis desenhados em canvas (`game.js`), então não há imagens para trocar. Para usar sprites próprios, substitua `drawSpr`.

## Estrutura

```
server.js          servidor HTTP + WebSocket + regras do jogo
index.html         telas (login, HUD, controles)
style.css          visual
game.js            cliente: desenho, entrada, rede
data/players.json  criado automaticamente ao salvar
```

## Limitações conhecidas / próximos passos

Sem PvP, guildas, inventário de equipamentos nem múltiplos mapas. Senhas são guardadas com scrypt, mas o servidor não faz HTTPS sozinho: ao expor na internet, use uma hospedagem ou proxy com HTTPS. Ideias: itens e equipamentos, PvP em áreas específicas, masmorras, mais classes.
